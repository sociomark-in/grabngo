<div class="bg-light py-3">
    <div class="container">
        <div class="row m-0 justify-content-between">
            <div class="col-md-auto col-12">
                <div class="d-flex align-items-center d-none">
                    Powered By<img src="<?= base_url("assets/") ?>core_hms.svg" alt="Logo" height="20">
                </div>
                &copy;<?= date("Y"); ?>.&nbsp;All Rights Reserved 
            </div>
            <div class="col-md-auto col-12"></div>
        </div>
    </div>
</div>